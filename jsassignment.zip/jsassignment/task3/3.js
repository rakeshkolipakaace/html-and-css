'MY NAME IS :'
'Rakesh'
'MY NAME IS :' + 'Rakesh'
console.log('Total cost: $' + (5 + 3))
console.log(`Total cost: $${5 + 3}`)
alert(`Total cost: $${5 + 3}`);
console.log('Total cost: $' + (599 + 295) / 100)
console.log(`Total cost: $${(599 + 295) / 100}`)
alert(`Total cost: $${(599 + 295) / 100}`);
alert(`Total cost: $${(599 + 295) / 100}
Thank you, come again!`);
console.log(`Items (${2 + 2}): $${(2 * 2095 + 2 * 799) / 100}`)
console.log(`Shipping & handling: $${(499 + 499) / 100}`)
console.log(`Total before tax: $${(2 * 2095 + 2 * 799 + 499 + 499) / 100}`)
console.log(`Estimated tax (10%): $${Math.round((2 * 2095 + 2 * 799 + 499 + 499) * 0.1) / 100}`)